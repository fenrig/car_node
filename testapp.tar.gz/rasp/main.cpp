#include <QCoreApplication>
#include <stdlib.h>
#include <QDebug>

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);
    qDebug() << "TEST\n";
    return a.exec();
}
